import './navbar.css';
import { useState, useEffect } from 'react';
import menu from "./mockdata.js"

function Navbar() {

    const [menuData, setMenuData] = useState(menu)
    const [data, setData] = useState()
    

    console.log(menuData)
    const updateData = () => {
        setMenuData(() => [...menuData, { title: "iphone 17" }])
        alert("You have changed sucessfully", menuData[menuData.length-1].title)  
    }

    useEffect(() => {
        console.log("data Here ")
    }, [data])
    
    useEffect(() => {
        console.log("MenuData")
        setData("raviteja")
    },[menuData])


    return (
        <div className="nav-bar">
            <div className="img-and-links">
                <img src="./images.png" alt="" />
                <ul className="nav-links">
                    {menuData.map((el) => (
                        <li>{el.title}</li>
                    ))}
                </ul>
            </div>

            <div className="search-icon">
            </div>
            <div>
                <button onClick={updateData}>
                    Add
                </button>
            </div>

        </div>
    )
}
export default Navbar