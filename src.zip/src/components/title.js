
function Title() {
    return (
        <div className="title-styles">
            <div class="column large-8 small-12 rs-shop-header-section" data-autom="shop-header">
                <h1 class="rs-shop-header">Store.</h1>
<div class="rs-shop-subheader">The best way to buy the products you love.</div>
            </div>
        </div>
    )



    
}
export default Title
