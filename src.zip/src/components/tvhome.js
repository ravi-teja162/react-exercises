function Tvhome() {
    return (

        <div className="Mac-Container">

            <div className="Mac-title">
                <h1>
Tvhome
                </h1>
            </div>

            <div className="Mac-video">
                <div className="welcome-video-content-container"  >
               
                <img className="welcome-video" src="https://www.apple.com/v/tv-home/o/images/overview/hero__dbphk49ymi2q_large_2x.jpg"></img>
                </div>
            </div>
        </div>
    )
}
export default Tvhome;