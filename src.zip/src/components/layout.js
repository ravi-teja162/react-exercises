import Navbar from "./navbar";
function Layout({ children }) {

    return (
        
        <div className="layout-styles">
            <Navbar/>
        {children}
        </div>
    )
    
}
export default Layout;