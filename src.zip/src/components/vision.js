function Vision() {
    return (

        <div className="Mac-Container">

            <div className="Mac-title">
                <h1>
Vision
                </h1>
            </div>

            <div className="Mac-video">
                <div className="welcome-video-content-container"  >
               
                <img className="welcome-video" src="https://www.apple.com/v/apple-vision-pro/g/images/overview/hero/portrait_base_us__fucaqiry5e2q_large_2x.jpg"></img>
                </div>
            </div>
        </div>
    )
}
export default Vision;