import { useState, useEffect } from 'react';
import './mobile.css';

function Mobile({ name, image, color, description}) {
  
    return (
        <div className='item'>
            <div className='image'>
                <img src={image}/>
            </div>
            <div className='phone-name'>
                <h2>{name}</h2>
            </div>
            <div className='color'>
                {color}
            </div>
            <div className='description'>
                <p>{ description}</p>
            </div>


        </div>

    )
}

export default Mobile;