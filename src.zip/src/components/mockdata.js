const menu = [

    { "title": "Store",  },
    { "title": "Iphone" },
    { "title": "Mac", "link":"/mac" },
    { "title": "Vision", "link":"/vision" },
    { "title": "Tvhome", "link":"/tvhome" }
];
export default menu