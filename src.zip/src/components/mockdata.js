const menu = [

    { "title": "Store" },
    { "title": "Iphone" },
    { "title": "Mac" },
    { "title": "Ipad" },
    { "title": "Airpods" }
];
export default menu