
import Link from './link';
import Title from './title';
import Product from './product';
import Layout from './layout';
import { items } from './mock';
import { useState, useEffect } from 'react';
import Mac from './mac';


function Home() {
    return (
        <div>
            <div className='Front-title-link'>
                <Title />
                <div className='links-styles'>
                    <Link title="Need Shopping Help?" icon="" link="Ask a specialist" />
                    <Link title="Visit Apple Store" icon="" link="Find one near you" />
                </div>
            </div>
            <div className='MacBasket'>
                <Mac></Mac>
            </div>

            <div className='product-basket-in-App'>
                {items.map((p, index) => (
                    <div key={index}>
                        <Product title={p?.value?.items[0]?.value.cardType.contentCard.contentStoreCard.headline}
                            image={p?.value?.items[0].value.cardType.contentCard.contentStoreCard.cardImage.srcSet.src} />
                    </div>
                ))}
            </div>
      </div > 

    )
}
export default Home