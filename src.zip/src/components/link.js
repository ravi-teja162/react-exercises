function Link({ title, icon, link }) {
    return (


        <div className="link-section">
            <div className="logo-link">

            </div>
            <div className="title-package">
            <div className="title-link">
                {title}
            </div>
            <div className="link-link">
                <a href=""> {link}</a>
            </div>
            </div>


        </div>

    )
}
export default Link



