function Product({title, image}) {
    return (
        <div className="product-image-class">
            <img src={image}>
            
            </img>
            <h1>
                {title}
            </h1>

        </div>
    )
}
export default Product