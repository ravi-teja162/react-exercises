import Mobile from "./items/mobile";
import { useState } from "react";
import './mobile_main_styles.css'

function Mobile_main() {
    const [mobiles, setMobiles] = useState([]);

    function get_data() {
        const name = prompt("Enter Phone Name");
        const image = prompt("Enter image");
        const color = prompt("Enter Color");
        const description = prompt("Enter Description");

        const newMobile = { name, image, color, description };

       
        setMobiles([newMobile,...mobiles ]);
    }

    return (
        <div className="main-content">
            <div className="add-button">
            <button onClick={get_data} >Add Mobile</button>
            </div><div className="mobile-content">
                {mobiles.map((mobile) => (
                    <Mobile {...mobile} />
                ))}
            </div>
        </div>
    );
}

export default Mobile_main;