function Mac() {
    return (

        <div className="Mac-Container">

            <div className="Mac-title">
                <h1>
MAC
                </h1>
            </div>

            <div className="Mac-video">
                <div className="welcome-video-content-container"  >
               
                <video className="welcome-video" autoPlay muted playsInline loop src="https://www.apple.com/105/media/us/mac/family/2025/59856fc1-d007-421a-90ee-734ddf3fd25d/anim/welcome/large_2x.mp4"></video>
                </div>
            </div>
        </div>
    )
}
export default Mac;