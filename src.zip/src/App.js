import './App.css';
import Navbar from './components/navbar';
import Link from './components/link';
import Title from './components/title';
import Product from './components/product';
import Layout from './components/layout';
import { items } from './components/mock';
import { useState, useEffect } from 'react';
import Mac from './components/mac';
import Vision from './components/vision';
import Tvhome from './components/tvhome';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './components/home';

function App() {
  const [product, setProductState] = useState(items);

  useEffect(() => {
    console.log(product);
  }, []);

  return (
    <Layout>
      <BrowserRouter>
        <Routes>
          <Route path='/home' element={<Home />}></Route>
          <Route path='/mac' element={<Mac />}></Route>
          <Route path='/vision' element={<Vision />}></Route>
          <Route path='/tvhome' element={<Tvhome />}></Route>
        </Routes>

      </BrowserRouter>
    </Layout>
  );
}

export default App;
