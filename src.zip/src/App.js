import logo from './logo.svg';
import './App.css';
function App() {
  return (
    <div>
    <h1>This is App component</h1></div>
  )
}

export default App;
