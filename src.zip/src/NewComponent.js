function NewComponent() {
  return (
    <div className="App">
    Raviteja         
    </div>
  );
}

export default NewComponent;
